package comm.flights;

public class Flight
{	
	public String image_url;
	public String name;
	public String source;
	public String destination;
	public String[] src;
	public String[] src_time;
	public String[] dest;
	public String[] dest_time;
	public int time;
	public int price;
	public int legs;

	public Flight(String image_url, String name, String source, String destination, int price, int time, int legs, String[] src, String[] dest, String[] src_time, String[] dest_time)
	{
		this.image_url = image_url;
		this.name = name;
		this.source = source;
		this.destination = destination;
		this.price = price;
		this.src = src;
		this.src_time = src_time;
		this.dest = dest;
		this.dest_time = dest_time;
		this.time = time;
		this.legs = legs;
	}
}
