package comm.flights;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

class Item
{
	public String source;
	public String destination;
	public int time;
}


/**
 * Servlet implementation class showFlightInfo
 */
@WebServlet("/showFlightInfo")
public class showFlightInfo extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public showFlightInfo()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		response.setContentType("application/json");
		response.setCharacterEncoding("utf-8");
		response.addHeader("Access-Control-Allow-Origin", "http://localhost:3000");
		response.addHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE, HEAD");
		PrintWriter out = response.getWriter();

		Gson gson = new Gson();
		Item item = new Item();
		item.source = request.getParameter("source");
		item.destination = request.getParameter("destination");
		item.time = Integer.parseInt(request.getParameter("time"));

		System.out.println(item.source);
		ArrayList<Flight> flights = new ArrayList<>();
		
		
		
		
		
		
		String [] arr1 = {"Kolkata"}; String[] arr2 = {"Mumbai"}; String[] arr3 = {"03:00 AM"}; String[] arr4 = {"05:00 AM"};
		flights.add(new Flight("https://s1.apideeplink.com/images/airlines/49.png","Indigo","Kolkata", "Mumbai", 4500, 3, 1,arr1,arr2,arr3,arr4));
		
		String [] arr5={"Kolkata","Bhubaneswar"}; String [] arr6={"Bhubaneswar","Mumbai"}; String [] arr7={"06:00 AM","07:30 AM"}; String [] arr8={"07:00 AM","10:00 AM"};
		flights.add(new Flight("https://s1.apideeplink.com/images/airlines/IX.png","AirIndia","Kolkata", "Mumbai", 4000, 6, 2, arr5,arr6,arr7,arr8));
		
		String [] arr11 = {"Kolkata"}; String[] arr12 = {"Mumbai"}; String[] arr13 = {"07:00 PM"}; String[] arr14 = {"10:00 PM"};
		flights.add(new Flight("https://s1.apideeplink.com/images/airlines/EK.png","Emirates","Kolkata", "Mumbai", 4900, 19, 1,arr11,arr12,arr13,arr14));
		
		String [] arr21={"New Delhi","Jaipur"}; String [] arr22={"Jaipur","Mumbai"}; String [] arr23={"12:00 PM","02:30 PM"}; String [] arr24={"02:00 PM","5:00 PM"};
		flights.add(new Flight("https://s1.apideeplink.com/images/airlines/49.png","Indigo","New Delhi", "Mumbai", 5100, 12, 2, arr21,arr22,arr23,arr24));
		
		flights.add(new Flight("https://s1.apideeplink.com/images/airlines/49.png","Indigo","New Delhi", "Mumbai", 5500, 14, 1,arr1,arr2,arr3,arr4));
		
		flights.add(new Flight("https://s1.apideeplink.com/images/airlines/49.png","Indigo","New Delhi", "Mumbai", 7500, 21, 1,arr1,arr2,arr3,arr4));
		
		String [] arr61 = {"Kolkata"}; String[] arr62 = {"New Delhi"}; String[] arr63 = {"11:00 AM"}; String[] arr64 = {"01:00 PM"};
		flights.add(new Flight("https://s1.apideeplink.com/images/airlines/EK.png","Emirates","Kolkata", "New Delhi", 3500, 11, 1,arr61,arr62,arr63,arr64));
		
		String [] arr71 = {"Kolkata"}; String[] arr72 = {"New Delhi"}; String[] arr73 = {"04:00 PM"}; String[] arr74 = {"07:00 PM"};
		flights.add(new Flight("https://s1.apideeplink.com/images/airlines/49.png","Indigo","Kolkata", "New Delhi", 6500, 16, 1,  arr71,arr72,arr73,arr74));
		
		String [] arr31={"Kolkata","Patna"}; String [] arr32={"Patna","New Delhi"}; String [] arr33={"08:00 PM","09:30 PM"}; String [] arr34={"09:00 PM","11:30 PM"};
		flights.add(new Flight("https://s1.apideeplink.com/images/airlines/IX.png","AirIndia","Kolkata", "New Delhi", 7500, 20, 2, arr31,arr32,arr33,arr34));
		
		String [] arr41={"Kolkata","Bhubaneswar"}; String [] arr42={"Bhubaneswar","Mumbai"}; String [] arr43={"06:00 AM","07:00 AM"}; String [] arr44={"07:30 AM","10:00 AM"};
		flights.add(new Flight("https://s1.apideeplink.com/images/airlines/49.png","Indigo","Mumbai", "New Delhi", 3500, 1, 2, arr41,arr42,arr43,arr44));
		
		String [] arr51={"Kolkata","Bhubaneswar"}; String [] arr52={"Bhubaneswar","Mumbai"}; String [] arr53={"06:00 AM","07:00 AM"}; String [] arr54={"07:30 AM","10:00 AM"};
		flights.add(new Flight("https://s1.apideeplink.com/images/airlines/49.png","Indigo","Mumbai", "New Delhi", 6600, 8, 2, arr51,arr52,arr53,arr54));
		
		flights.add(new Flight("https://s1.apideeplink.com/images/airlines/49.png","Indigo","Mumbai", "New Delhi", 7100, 22, 1,arr1,arr2,arr3,arr4));

		
		
		
		
		
		
		
		
		ArrayList<Flight> result = new ArrayList<>();
		for (Flight flight : flights) {
			if (flight.source.equals(item.source) && flight.destination.equals(item.destination)
					&& flight.time >= item.time)
				result.add(flight);
		}

		GsonBuilder gsonBuilder = new GsonBuilder();
		Gson gson2 = gsonBuilder.create();
		String json = gson2.toJson(result);
		out.print(json);

	}

}
