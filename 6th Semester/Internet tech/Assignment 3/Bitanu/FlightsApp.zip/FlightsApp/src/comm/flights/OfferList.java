package comm.flights;

import java.util.ArrayList;

class Offer
{

	private String image_url, name, source, destination;
	private int cost, reduced_cost, time;

	public Offer(String image_url, String name, String source, String destination, int cost, int reduced_cost, int time)
	{	
		this.image_url = image_url;
		this.name = name;
		this.source = source;
		this.destination = destination;
		this.cost = cost;
		this.reduced_cost = reduced_cost;
		this.time = time;
	}
}

public class OfferList
{

	ArrayList<Offer> arrayList;

	public OfferList()
	{
		arrayList = new ArrayList<>();
	}

	public void addOffer(String image_url, String name, String source, String destination, int cost, int reduced_cost, int time)
	{
		Offer offer = new Offer(image_url, name, source, destination, cost, reduced_cost, time);
		arrayList.add(offer);
	}
	public ArrayList<Offer> getOfferList() {
		return arrayList;
	}

}