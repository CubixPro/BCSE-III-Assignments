package comm.flights;

import java.io.IOException;
import java.io.PrintWriter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;


import java.util.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import comm.flights.*;

/**
 * Servlet implementation class getFlightInfoServlet
 */
@WebServlet("/getFlightInfo")
public class getFlightInfoServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public getFlightInfoServlet()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{

		OfferList offerList = new OfferList();
		offerList.addOffer("https://s1.apideeplink.com/images/airlines/49.png","Indigo","Bangalore", "New Delhi", 4299, 1999, 8);
		offerList.addOffer("https://s1.apideeplink.com/images/airlines/IX.png","AirIndia","New Delhi", "Bangalore", 3500, 2499, 18);
		offerList.addOffer("https://s1.apideeplink.com/images/airlines/EK.png","Emirates","Bangalore", "New Delhi", 5500, 3999, 20);
		ArrayList<Offer> offers = offerList.getOfferList(); 
		
		response.setContentType("application/json");
		response.setCharacterEncoding("utf-8");
		response.addHeader("Access-Control-Allow-Origin", "http://localhost:3000");
		response.addHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, PUT, DELETE, HEAD");
		PrintWriter out = response.getWriter();
		
		GsonBuilder gsonBuilder = new GsonBuilder();
		Gson gson = gsonBuilder.create();
		String json = gson.toJson(offers);
		out.print(json);

	}

}
